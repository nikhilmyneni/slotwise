# SlotWise full dataset

Synthetic warehouse slotting data generated with seed `20261022`. Regenerate from the repository root with `python -m slotting all --scale full --seed 20261022`.

- `data/csv/` and `data/json/`: operational input tables.
- `data/slotting.db` and `data/seed.sql`: SQLite database and SQL seed (unless `--no-sql` was used).
- `results/`: proposals, simulation comparisons, exceptions and metrics.
- `ground_truth/`: separate labelled answer key. Never use as input features.
- `DATA_DICTIONARY.md`: fields, keys, values, units and validation rules.
- `validation_summary.json`: integrity and business-rule checks.
- `manifest.json`: provenance, source command, versions, row counts and SHA-256 hashes.
- `repro_report.json`: optional two-run row count and checksum comparison.

All records are synthetic; no external data or personal information is included.
